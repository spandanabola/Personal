

var module = angular.module('ServiceAppOne', ['ui.bootstrap']);


module.service('ContactService', function () {

    var uid = 11;
     

    var contacts = [{
		
		
        id: 1,
        'name': 'Rahul',
            'date': '2016-12-12',
            'Manufacture': 'Coca-Cola',
			'Package': 'loren-lpsum',
			'Brand': 'loren-lpsum'
			
			
    },
	{
		
		
        id: 2,
        'name': 'Ram',
            'date': '2016-10-12',
            'Manufacture': 'Coca-Cola',
			'Package': 'loren-lpsum',
			'Brand': 'loren-lpsum'
			
			
    },
	
	{
		
		
        id: 3,
        'name': 'Krishna',
            'date': '2016-01-01',
            'Manufacture': 'Coca-Cola',
			'Package': 'loren-lpsum',
			'Brand': 'loren-lpsum'
			
			
    },
	
	{
		
		
        id: 4,
        'name': 'Vilas',
            'date': '2014-11-12',
            'Manufacture': 'Coca-Cola',
			'Package': 'loren-lpsum',
			'Brand': 'loren-lpsum'
			
			
    },
	
	{
		
		
        id: 5,
        'name': 'Vikrant',
            'date': '2016-08-19',
            'Manufacture': 'Coca-Cola',
			'Package': 'loren-lpsum',
			'Brand': 'loren-lpsum'
			
			
    },
	
	{
		
		
        id:6,
        'name': 'Vybhav',
            'date': '2012-11-12',
            'Manufacture': 'Coca-Cola',
			'Package': 'loren-lpsum',
			'Brand': 'loren-lpsum'
			
			
    },
	
	{
		
		
        id: 7,
        'name': 'Kosik',
            'date': '2013-02-12',
            'Manufacture': 'Coca-Cola',
			'Package': 'loren-lpsum',
			'Brand': 'loren-lpsum'
			
			
    },
    
	{
		
		
        id: 8,
        'name': 'Vikrant',
            'date': '2016-08-19',
            'Manufacture': 'Coca-Cola',
			'Package': 'loren-lpsum',
			'Brand': 'loren-lpsum'
			
			
    },
	
	{
		
		
        id:9,
        'name': 'Vybhav',
            'date': '2012-11-12',
            'Manufacture': 'Coca-Cola',
			'Package': 'loren-lpsum',
			'Brand': 'loren-lpsum'
			
			
    },
	{
		
		
        id: 10,
        'name': 'Paul',
            'date': '2015-10-10',
            'Manufacture': 'Coca-Cola',
			'Package': 'loren-lpsum',
			'Brand': 'loren-lpsum'
			
			
    }
	
	];
     

    this.save = function (contact) {
        if (contact.id == null) {

            contact.id = uid++;
            contacts.push(contact);
        } else {

            for (i in contacts) {
                if (contacts[i].id == contact.id) {
                    contacts[i] = contact;
                }
            }
        }
 
    }
 

    this.get = function (id) {
        for (i in contacts) {
            if (contacts[i].id == id) {
                return contacts[i];
            }
        }
 
    }
     

    this.deletedata = function (id) {
        for (i in contacts) {
            if (contacts[i].id == id) {
                contacts.splice(i, 1);
            }
        }
    }

    this.list = function () {
        return contacts;
    }
});


module.controller('ContactController', function ($scope,$dialog,ContactService) {
	
	
	  var dialogOptions = {
			    controller: 'EditCtrl',
			    templateUrl: 'cokewebadd.html'
			  };
	  var dialogOptionsEdit = {
			    controller: 'EditCtrl',
			    templateUrl: 'cokewebedit.html'
			  };
    $scope.contacts = ContactService.list();
    $scope.data={};
    
    $scope.saveContact = function () {
        ContactService.save($scope.newcontact);
        $scope.newcontact = {};
    }
 
   $scope.add = function(item){                      //Add popup
 
	    var itemToEdit = item;
	    
	    $dialog.dialog(angular.extend(dialogOptions, {resolve: {item: angular.copy(itemToEdit)}}))
	      .open()
	      .then(function(result) {
	        if(result) {
	          angular.copy(result, itemToEdit);                
	        }
	        itemToEdit = undefined;
    });
  };
  
  
  $scope.edit = function(item){                       //Edit popup
	  
	    var itemToEdit = item;
	    $dialog.dialog(angular.extend(dialogOptionsEdit, {resolve: {item: angular.copy(itemToEdit)}}))
	      .open()
	      .then(function(result) {
	        if(result) {
	          angular.copy(result, itemToEdit);                
	        }
	        itemToEdit = undefined;
	    });
	  };
	  
    $scope.deletedata = function (id) {              //For deleting the data
 
        ContactService.deletedata(id);
        if ($scope.newcontact.id == id) $scope.newcontact = {};
    }
    
    $scope.change =function(id){                     //For deleting the data based on ID
	 if(id)
		 $scope.newcontact = angular.copy(ContactService.get(id));
		else
			$scope.newcontact = {};
	};
})

module.run(function($rootScope) {                    //For editing the data
    $rootScope.ChangeStatus = function(item){
		if(item){
			 $rootScope.newContact = item;
			 }
		else
			$rootScope.newContact = {};
	};
});


function EditCtrl($scope, item, dialog){
	  
	  $scope.item = $scope.newContact;
	  $scope.data =  $scope.newContact;
	  console.log($scope.data);
	  $scope.save = function() {
	    dialog.close($scope.item);
	  };
	  
	  $scope.close = function(){
	    dialog.close(undefined);
	  };
	}
